import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Post from '@/components/Post'
import Get from '@/components/Get'
import Container from '@/components/Container'
import Login from '@/components/Login'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login,
      alias: '/Login'
    },
    {
      path: '/post',
      name: 'Post',
      component: Post
    },
    {
      path: '/get',
      name: 'Get',
      component: Get
    },
    {
      path: '/container',
      name: 'Container',
      component: Container
    },
	{
      path: '/Home',
      name: 'Home',
      component: Home
    },
	{
      path: '/Login/Home',
      name: 'Home',
      component: Home
    }
  ]
})
