<template>
  <div>
	
        

      <div class="post-form">
        <md-card class="md-layout-item md-size-50 md-large-size-50 md-medium-size-70 md-small-size-90 md-xsmall-size-100">
          <md-card-header>
            <div  class="title">Login</div>
          </md-card-header>

          <md-card-content class="post-card">
         

            <div v-if="scAction == 'ship' || !showSC">
              <div class="md-layout md-gutter">
                <div class="md-layout-item md-size-50">
                  <md-field>
                    <label for="username">User Name</label>
                    <md-input name="username" id="username" v-model="form1.username" :disabled="sending" />
                  </md-field>
                </div>
				</div>
				 <div class="md-layout md-gutter">
                <div class="md-layout-item md-size-50">
                  <md-field>
                    <label for="password">Password</label>
                    <md-input type="password" name="password" id="password" v-model="form1.password" :disabled="sending" />
                  </md-field>
                </div>
              </div>
             

            </div>
          </md-card-content>

          <md-progress-bar class="md-accent" md-mode="indeterminate" v-if="sending"/>

          <md-card-actions>
            <md-button  type="submit" class="md-accent md-raised" :disabled="!(form1.username && form1.password )"  v-on:click="saveRecord()">Login</md-button>
          </md-card-actions>
        </md-card>

      </div>
    </div>

  </div>
</template>

<script>
import { localstorage } from './mixins/localstorage'
import ethers from 'ethers'
import simbaApi from './gateways/simba-api'

export default {
  name: 'Login',
   data: () => ({
    role1: null
  }),
  mounted () {
    if (localStorage.getItem('role1')) {
      this.role1 = localStorage.getItem('role1')
    }
  },
  methods: {
    changeRole () {
		if (this.form1.username=='Mohan'){
           localStorage.setItem('role1', 'CAT')
		}
		else {
			alert('Supplier')
		}
    }
  },
  mixins: [localstorage],

  data: () => ({
    scAction: null,
    saveRecord (e) {
		if (this.form1.username=='Mohan' || this.form1.username=='Chakri' || this.form1.username=='Sripada' || this.form1.username=='Bruce'){
           localStorage.setItem('role1', 'CAT')
		   localStorage.setItem('role', 'mf')
		}
		else if (this.form1.username=='Jacquie') {
			localStorage.setItem('role1', 'ServiceCenter')
			localStorage.setItem('role', 'sc')
		}
		else  {
			localStorage.setItem('role1', 'SUPPLIER')
			localStorage.setItem('role', 'su')
		}
	this.$router.push("/Home")
	},

    form1: {
      username: null,
      password: null
    }
  })
}
</script>

<style scoped>

  .my-card {
    margin-top: 40px;
    width: 300px;
    display: inline-block;
    vertical-align: top;
    margin-bottom: 20px;
  }
  .md-progress-bar {
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
  }
  .post-form {
    margin-top: 40px;
    height: 550px;
  }
  .title {
    font-size: 20px;
    margin-left: 10px;
    margin-top: 7px;
  }
  .post-card {
    margin: 10px;
  }
  .options {
    margin-top: 40px;
  }
  .wallet {
    min-width: 320px;
  }
  .wallet-content {
    margin: 20px;
  }
</style>
