<template>
<div>
  <div v-if="showSUPP">
    <md-card class="md-alignment-center-center my-card" md-with-hover>
        <md-card-header>
          <div class="md-title">Quick Start</div>
          <div class="md-subhead">Select a party to begin</div>
        </md-card-header>
        <md-card-content>
          <div>
		    <md-radio v-model="role" value="su" v-on:change="changeRole"><strong>CAT Supplier (ITAMCO)</strong></md-radio>
			</div>
        </md-card-content>
		</md-card>
		</div>
		 <div v-if="showCAT">
		  <md-card class="md-alignment-center-center my-card" md-with-hover>
        <md-card-header>
          <div class="md-title">Quick Start</div>
          <div class="md-subhead">Select a party to begin</div>
        </md-card-header>
		<md-card-content>
          <div>
            <md-radio v-model="role" value="mf" v-on:change="changeRole"><strong>Manufacturing Plant</strong></md-radio>
			</div>
        </md-card-content>
    </md-card>
  </div>
  <div v-if="showSC">
		  <md-card class="md-alignment-center-center my-card" md-with-hover>
        <md-card-header>
          <div class="md-title">Quick Start</div>
          <div class="md-subhead">Select a party to begin</div>
        </md-card-header>
		<md-card-content>
          <div>
            <md-radio v-model="role" value="sc" v-on:change="changeRole"><strong>Service Center</strong></md-radio>
			</div>
        </md-card-content>
    </md-card>
  </div>
  </div>
</template>

<script>

export default {
  name: 'Home',
  data: () => ({
    role: null,
	showCAT: false,
	showSUPP: false,
	showSC: false
  }),
  mounted () {
	if (localStorage.getItem('role1')=='CAT') {
      this.showCAT = true
    }  
	else if (localStorage.getItem('role1')=='SUPPLIER') {
		this.showSUPP = true
	}
	else {
		this.showSC = true
	}
    if (localStorage.getItem('role')) {
      this.role = localStorage.getItem('role')
    }
  },
  methods: {
    changeRole () {
      localStorage.setItem('role', this.role)
    }
  }
}
</script>

<style lang="scss" scoped>
  .my-card {
    margin-top: 40px;
    width: 250px;
    display: inline-block;
    vertical-align: top;
    margin-bottom: 20px;
  }
</style>
